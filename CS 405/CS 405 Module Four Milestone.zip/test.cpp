// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
#include <stdexcept> // needed for out_of_range
#include <cassert> // inclueds assert
#include <memory> // needed for unique_ptr
#include <vector> // needed for vector functions
#include <ctime> // gets time functions
#include <cstdlib> // utility functions

// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//    FAIL();
//}

// Creates a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    // add 
    add_entries(1);

    // is the collection still empty?
    EXPECT_FALSE(collection->empty());

    // if not empty, what must the size be?
    EXPECT_EQ(collection->size(), 1);
}

// Creates a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // assert that the collection is empty
    ASSERT_TRUE(collection->empty());

    // add 5 entries
    add_entries(5);

    // expects the collection to not be empty
    EXPECT_FALSE(collection->empty());

    // expects the size to be 5
    EXPECT_EQ(collection->size(), 5);
}

// Creates a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsAlwaysGreaterThanOrEqualToSize) 
{
    // check for 0 entries
    EXPECT_GE(collection->max_size(), collection->size());

    // check for 1 entry
    add_entries(1);
    EXPECT_GE(collection->max_size(), collection->size());

    // check for 5 entries (total 6)
    add_entries(5);
    EXPECT_GE(collection->max_size(), collection->size());

    // check for 10 entries (total 16)
    add_entries(10);
    EXPECT_GE(collection->max_size(), collection->size());
}

// Creates a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsAlwaysGreaterThanOrEqualToSize) 
{
    // check for 0 entries
    EXPECT_GE(collection->capacity(), collection->size());

    // check for 1 entry
    add_entries(1);
    EXPECT_GE(collection->capacity(), collection->size());

    // check for 5 entries (total 6)
    add_entries(5);
    EXPECT_GE(collection->capacity(), collection->size());

    // check for 10 entries (total 16)
    add_entries(10);
    EXPECT_GE(collection->capacity(), collection->size());
}

// Creates a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizingIncreasesCollectionSize) 
{
    // adds 5 entries
    add_entries(5);
    // sets intial size to the collection size (total 5)
    size_t initialSize = collection->size();

    // change collection size (total 15)
    collection->resize(15);

    // expect the collection size to now be 15
    EXPECT_EQ(collection->size(), 15);
    // check that the new collection size is greater than the intial size
    ASSERT_GT(collection->size(), initialSize);
}

// Creates a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizingDecreasesCollectionSize) 
{
    // adds 10 entries
    add_entries(10);
    // setsi initial size to the collection size (total 10)
    size_t initialSize = collection->size();

    // resizes collection (total 4)
    collection->resize(4);

    // expects collection will now be 4
    EXPECT_EQ(collection->size(), 4);
    // compares current collection size to intial size to ensure it is smaller
    ASSERT_LT(collection->size(), initialSize);
}

// Creates a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizingDecreasesCollectionToZeroSize) 
{
    // adds 5 entries
    add_entries(5);

    // resizes collection to 0
    collection->resize(0);

    // expects collection size to = 0
    EXPECT_EQ(collection->size(), 0);
    // test passes if collection is empty
    EXPECT_TRUE(collection->empty());
}

// Creates a test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesAllElementsInCollection) 
{
    // adds 5 entries to collection
    add_entries(5);
    // should continue is the collection isn't empty
    ASSERT_FALSE(collection->empty());

    // clears collection using clear method
    collection->clear();

    // expects collection size to = 0
    EXPECT_EQ(collection->size(), 0);
    // test passes if collection is empty
    EXPECT_TRUE(collection->empty());
}

// Creates a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseBeginToEndLeavesCollectionEmpty) 
{
    // adds 5 entries to collection
    add_entries(5);
    // should continue is the collection isn't empty
    ASSERT_FALSE(collection->empty());

    // erases beginning and end of collection using erase method
    collection->erase(collection->begin(), collection->end());

    // expects collection size to = 0
    EXPECT_EQ(collection->size(), 0);
    // test passes if collection is empty
    EXPECT_TRUE(collection->empty());
}

// Creates a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityWithoutChangingSize) 
{
    // adds 5 entries to collection
    add_entries(5);
    // sets initial size to collection size (total 5)
    size_t initialSize = collection->size();
    // sets the initial capacity (total 5)
    size_t initialCapacity = collection->capacity();

    // changes reserve to initial capacity + 20 (total 25)
    collection->reserve(initialCapacity + 20);

    // expects the size to stay the same
    EXPECT_EQ(collection->size(), initialSize);
    // expects the reserve capacity to be >= intial cpapacity
    EXPECT_GE(collection->capacity(), initialCapacity + 20);
}

// Creates a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, AtThrowsOutOfRangeWhenIndexIsOutOfBoundsHigh) 
{
    // adds 5 entries to the collection
    add_entries(5); // valid indices are 0 through 4

    // attempting to access index 5 must throw std::out_of_range
    EXPECT_THROW(collection->at(5), std::out_of_range);
}

// Creates 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
// Custom Test 1 (Positive): Verify that modifying elements via front() changes the internal value correctly
TEST_F(CollectionTest, CustomPositiveFrontModifierChangesFirstElement) 
{
    // adds 3 entries
    add_entries(3);

    // modifies the front element
    collection->front() = 999;

    // expects the front number to = 999
    EXPECT_EQ(collection->at(0), 999);
}

// Custom Test 2 (Negative): Verify that calling at() on a completely empty vector throws an out_of_range exception
TEST_F(CollectionTest, CustomNegativeAtThrowsOutOfRangeWhenCollectionIsEmpty) 
{
    // collection is default-initialized to size 0
    ASSERT_TRUE(collection->empty());

    // accessing index 0 on an empty container must throw an exception
    EXPECT_THROW(collection->at(0), std::out_of_range);
}