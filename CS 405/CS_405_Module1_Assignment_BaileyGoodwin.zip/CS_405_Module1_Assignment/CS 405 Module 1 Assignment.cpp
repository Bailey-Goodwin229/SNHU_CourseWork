// CS 405 Module 1 Assignment.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start + (increment * steps)</returns>
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Overflow precondition check, detects when overflow happens
        // Subtracts the increment from the absolute maximum threshold before modifying the variable. 
        // If our current value exceeds this boundary, performing the addition would cause undefined behavior overflow.
        if (increment > 0 && result > std::numeric_limits<T>::max() - increment) {
            throw std::overflow_error("Overflow detected!"); // stops it and returns error
        }

        // increments result if there is no overflow
        result += increment;
    }

    // returns result if no overflow
    return result;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps)</returns>

template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Underflow precondition check
        // Adds the decrement value to the lowest baseline. 
        // If our current total sits below this sum, subtracting again would push the variable past its bottom bounds.
        if (decrement > 0 && result < std::numeric_limits<T>::lowest() + decrement) {
            throw std::underflow_error("Underflow detected"); // throws an error and returns underflow error message
        }

        // Decrements result if there is no underflow detected
        result -= decrement;
    }

    // Returns value if no underflow
    return result;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // TODO: The add_numbers template function will overflow in the second method call
    //        You need to change the add_numbers method to:
    //        1. Detect when an overflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no overflow happened or
    //        4. Return something to tell test_overflow the addition failed
    //        NOTE: The add_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_overflow method to:
    //        1. Detect when an add_numbers failed
    //        2. Inform the user the overflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_overflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE
    // Declare variable outside of try/catch so it is recognized by the compiler
    T result;
    
    // prints start of overflow testing without overflow error
    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    // trys the function first
    try {
        // sets result to the add numbers method with non-overflow parameters
        result = add_numbers<T>(start, increment, steps);
        // prints result if no over flow is detected and lets user know
        std::cout << +result << " No overflow detected" << std::endl;
    // catchs an error if it fails due to overflow
    } catch (const std::overflow_error&) {
        // displays error message
        std::cout << "Error: Overflow occurred!" << std::endl;
    }
    
    // prints that it is starting testing with overflow, it does this by adding an extra step when max is split into 5 parts.
    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    try {
        // tries to set result to the add_number method with an extra step
        result = add_numbers<T>(start, increment, steps + 1);
        // prints result and confirmation of no overflow if no overflow occurs
        std::cout << +result<< " No overflow detected" << std::endl;
    // catches overflow error
    } catch (const std::overflow_error&) {
        //prints method to let user know of over flow error
        std::cout << "Error: Overflow occurred!" << std::endl;
    }
    
}

template <typename T>
void test_underflow()
{
    // TODO: The subtract_numbers template function will underflow in the second method call
    //        You need to change the subtract_numbers method to:
    //        1. Detect when an underflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no underflow happened or
    //        4. Return something to tell test_underflow the subtraction failed
    //        NOTE: The subtract_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_underflow method to:
    //        1. Detect when an subtract_numbers failed
    //        2. Inform the user the underflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_underflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE
    // Declare variable outside of try/catch so it is recognized by the compiler
    T result;

    // Changed typo from Overflow to Underflow based on what the instructions wanted
    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    // try block to try the method
    try {
        // sets the result to be the return value from the subtract_numbers method
        result = subtract_numbers<T>(start, decrement, steps);
        // returns success message if there is no underflow
        std::cout << +result << " No underflow detected" << std::endl;
    // catches an error if it occurs
    } catch (const std::underflow_error&) {
        // Displays error for the user to see
        std::cout << "Error: Underflow occurred!" << std::endl;
    }
    
    // Announces it will be subtracting numbers with Underflow in mind
    std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    // try/catch block
    try {
        // Sets result to equal the subtract_numbers method with an extra step which should trigger underflow
        result = subtract_numbers<T>(start, decrement, steps + 1);
        // returns messae if successful with no underflow
        std::cout << +result << " No underflow detected" << std::endl;
    }
    // catches error if there iss underflow
    catch (const std::underflow_error&) {
        // displays message for user to see
        std::cout << "Error: Underflow occurred!" << std::endl;
    }
    
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu