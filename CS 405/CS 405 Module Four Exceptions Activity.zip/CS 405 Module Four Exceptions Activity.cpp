// CS 405 Module Four Exceptions Activity.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include <stdexcept> // Required for standard exceptions
#include <string>

// Class for custom exception and message
class customException : public std::exception {
private:
    std::string message;
public:
    explicit customException(const std::string& msg) : message(msg) {}

    // Overrides the compiler error and allows us to throw our own custom built error with what()
    virtual const char* what() const noexcept override {
        return message.c_str();
    }
};

bool do_even_more_custom_application_logic()
{

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throws any standard exception
    throw std::runtime_error("Internal application state failure.");

    return true;
}
void do_custom_application_logic()
{
    //  Wraps the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    // Uses try/catch block to catch any errors or display approrpiate logic
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    } 
    // Catching the standard exception thrown by the internal logical operation
    catch (const std::exception& e) {
        std::cout << "EXCEPTION HANDLED: " << e.what() << std::endl;
        std::cout << "Continuing application processing safely..." << std::endl;
    }
    
    //  Throws a custom exception derived from std::exception
    //  and catch it explictly in main
    std::cout << "Leaving Custom Application Logic." << std::endl;

    throw customException("Security validation failed during application exit.");

}

float divide(float num, float den)
{
    // Throws an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0.0f) {
        throw std::invalid_argument("Division by zero is mathematically undefined.");
    }

    return (num / den);
}

void do_division() noexcept
{
    //  creates an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    // Uses try/except block to try logic or catch error if there's a failure
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e) {
        std::cout << "EXCEPTION HANDLED: " << e.what() << std::endl;
    }
    
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    //  Creates exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    try {
        do_division();
        do_custom_application_logic();
    }
    // Catch block specializing strictly in Custom Exception class
    catch (const customException& e) {
        std::cout << "CUSTOM EXCEPTION: " << e.what() << std::endl;
    }
    // Generic base class block catching all remaining variants derived from std::exception
    catch (const std::exception& e) {
        std::cout << "STANDARD EXCEPTION: " << e.what() << std::endl;
    }
    // Catch-all safety boundary handling any primitive, raw, or completely unhandled types
    catch (...) {
        std::cout << "CRITICAL ERROR: Caught a completely unknown, unhandled exception type." << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu